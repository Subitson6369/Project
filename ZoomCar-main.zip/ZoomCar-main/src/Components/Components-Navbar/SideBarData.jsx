					
export const SidebarData = [
{
	title: "Login or Signup",
	path: "/loginsignup",
	// icon: <IoPerson />,

},
{
	title: "Change City",
	path: "/selectcountry",

},
{
	title: "Become a Host",
	path: "/becomeahost",
},
{
	title: "Zoomcar Fleet Vehicles Policies",
	path: "/zoomcar-mobility-services",

},
{
	title: "Zoomcar Host Vehicles Policies",
	path: "/zoomcar-mobility-services",
},
{
	title: "Help & Support",
	path: "/support",
},
{
	title: "LogOut",
	path: "/login",
},
];

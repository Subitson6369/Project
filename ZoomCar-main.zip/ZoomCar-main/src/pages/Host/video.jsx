

function Rahul(){
    return <>
     <div id="body">
        <div id="youtube-video">
        <iframe width="820" height="461" src="https://www.youtube.com/embed/_zWKLHLj5kM" title="Zoomcar Host Rahul | Bangalore | Hear from our Hosts" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
     </div>
    </>
}

function Vanshika(){
    return <>
    <div id="body">
       <div id="youtube-video">
    <iframe width="820" height="461" src="https://www.youtube.com/embed/7uCM_Xw5cTI" title="Zoomcar Host Vanshika | Mumbai | Hear from our Hosts" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
     </div>
    </>
}
function Sai(){
    return <>
    <div id="body">
       <div id="youtube-video">
       <iframe width="820" height="461" src="https://www.youtube.com/embed/iFTFlp6WSsU" title="Zoomcar Host Sai Krishna | Hyderabad | Hear from our Hosts" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
     </div>
    </>
}


export { Rahul,Vanshika,Sai};